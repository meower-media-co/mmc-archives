var win = nw.Window.get();
win.setPosition("center")
win.setResizable(false)
//width: 800,
//height: 600