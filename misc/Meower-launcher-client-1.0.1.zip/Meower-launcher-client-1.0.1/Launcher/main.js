function delay(time) {
	return new Promise(resolve => setTimeout(resolve, time));
	//Make sure to put the function as "async runction"
}

function playaudio() {
	var audio = new Audio('Assets/Audio/hover.wav');
	audio.play();
}
function tomain() {
	document.getElementById('Center').style.visibility = 'hidden';
	document.getElementById('Meower').style.visibility = 'visible';
}

function playaudio2() {
	var audio2 = new Audio('Assets/Audio/start.wav');
	audio2.play();
}

async function changecssformeoweranim() {
	document.getElementById('MeowerMAIN').style.animation = 'shrinkgrowfade 1s';
	playaudio2()
	await delay(550)
	location.replace("https://www.Meower.org/Meower")
}

async function changecssformeoweranim2() {
	document.getElementById('WMeowerMAIN').style.animation = 'shrinkgrowfade 1s';
	playaudio2()
	await delay(550)
	var win = nw.Window.get();
	win.setResizable(true)
	win.resizeTo(1536, 832)
	win.moveTo(-6, 0)
	win.setResizable(false)
	location.replace("https://wiki.meower.org/")
}

async function changecssformeoweranim3() {
	document.getElementById('MeowerMAINp').style.animation = 'shrinkgrowfade 1s';
	playaudio2()
	await delay(550)
	var win = nw.Window.get();
	//win.setResizable(true)
	//win.resizeTo(1536, 832)
	//win.moveTo(-6, 0)
	//win.setResizable(false)
	location.replace("https://plus.meower.org/")
}

async function changecssformeoweranim4() {
	document.getElementById('Openly').style.animation = 'shrinkgrowfade 1s';
	playaudio2()
	await delay(550)
	var win = nw.Window.get();
	//win.setResizable(true)
	//win.resizeTo(1536, 832)
	//win.moveTo(-6, 0)
	//win.setResizable(false)
	location.replace("https://openly.meower.org/")
}
